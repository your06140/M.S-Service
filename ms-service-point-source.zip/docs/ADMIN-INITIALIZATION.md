# Controlled first administrator setup

This process grants the admin role to one explicitly verified account. There is no public admin sign-up, no hardcoded password, and the script never writes a password.

## Before starting

- Create a Supabase project and apply all three migrations.
- Enable Auth email confirmation; set the final `pages.dev` Site URL/redirect URL (or a temporary verified local URL) in Supabase Auth settings.
- Use an organization-controlled mailbox and a strong unique password. Protect the Supabase service-role key. Never put it in `VITE_*`, frontend code, GitHub or Cloudflare Pages variables.
- Install project dependencies locally: `npm install`.

## Invite and grant the first admin

From the project folder, in a trusted local terminal, set these environment variables for the current shell (do not save the values into a committed file):

```bash
export SUPABASE_URL='https://YOUR_PROJECT_REF.supabase.co'
export SUPABASE_SERVICE_ROLE_KEY='YOUR_PRIVATE_SERVICE_ROLE_KEY'
export ADMIN_EMAIL='admin@your-controlled-domain.example'
export ADMIN_REDIRECT_URL='https://YOUR_PROJECT.pages.dev/'
node scripts/grant-admin.mjs
```

If that email does not already exist, Supabase Auth sends its secure invitation. Complete the invite, set a strong password, and verify the email. If the account already exists, the script deliberately exits unless you explicitly confirm ownership:

```bash
export CONFIRM_EXISTING_USER_EMAIL="$ADMIN_EMAIL"
node scripts/grant-admin.mjs
```

The explicit confirmation is a safeguard, not proof of identity—verify the mailbox and intended user out of band first. The script inserts the `admin` role through the server-side service role and appends a minimal audit event. It does not create credentials or set a password. Rotate/revoke the service-role key if it is exposed.

## Verify safely

1. Log in through the portal with the invited account and check the Auth user is confirmed.
2. In a trusted SQL session, confirm a single `user_roles` row joins to `roles.code='admin'` for the expected Auth UUID. Do not share screenshots containing user PII or keys.
3. Check `audit_logs` for `admin.bootstrap` and check subsequent sensitive admin operations are logged.
4. Use a separate non-admin test account to verify it cannot select other profiles, read admin queues, modify `user_roles`, update its own account status, or read another user's documents.
5. Configure admin MFA in Supabase Auth and require it for production operations where available. Do not expose service-role credentials to an administrator's browser.

## Recovery / removal

To revoke admin, delete only that user's `admin` mapping from `user_roles` using a trusted SQL console after confirming the target UUID; keep their customer mapping intact. Use Supabase Auth password recovery/invitation for password reset. Never make a broad `DELETE`/`UPDATE` without a confirmed UUID and backup.
