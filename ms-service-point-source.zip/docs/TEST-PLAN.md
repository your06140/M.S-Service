# Test plan and deployment gate

## Automated checks run for this build

- `npm run build` — TypeScript check + optimized Vite build: passed.
- `npm audit --omit=dev` — 0 production dependency advisories at time of check.
- Full `npm audit` — currently reports unresolved high severity `picomatch` issues in development tool transitive dependencies (Tailwind/Vite); upstream fixed version was unavailable in this npm registry at build time. Recheck before release and use a fixed compatible version as soon as available.

## Manual test matrix — required after Supabase setup

Use at least two customer identities, one retailer, one distributor and one admin. Use throwaway accounts and non-sensitive sample info only. Never store reusable test passwords in GitHub or docs.

| # | Scenario | Expected result | Result |
|--:|---|---|---|
| 1 | Navigation, keyboard focus, narrow mobile width | All public/workspace pages usable; visible focus; no horizontal overflow | Not run against live browser |
| 2 | Customer registration | Supabase Auth confirmation email; customer/profile/role trigger rows | Pending |
| 3 | Login / logout | Valid session persists; sign out invalidates session | Pending |
| 4 | Password recovery | Redirect allow-list works; recovery flow safely updates password | Pending live redirect and password update verification |
| 5 | Customer dashboard | Only signed-in account information shown | Pending |
| 6 | Agent dashboard & approval | Pending agent cannot use active permissions; admin approval audited | Pending; production workflows incomplete |
| 7 | Admin gate | Non-admin denied by RLS even if client UI modified | Pending |
| 8 | Service request create | Available/manual services only; server-generated ID; owner can read | Pending |
| 9 | Request tracking/status | Owner and authorized admin see expected state; other customers denied | Pending |
| 10 | Document upload | 10 MiB max, allow-listed file types, private bucket, signed access only | Not implemented in UI; do not upload |
| 11 | Demo ledger | all entries labeled demo; customers cannot insert/change balances | Pending |
| 12 | RLS/security | attempt cross-user profile, customer, ticket, request, wallet and storage reads/writes; all deny | Pending live SQL tests |
| 13 | Responsive | Android Chrome, iOS Safari, tablet and desktop viewport checks | Pending device/browser testing |
| 14 | Error handling | offline, expired session, duplicate submission and RLS errors remain safe | Pending |
| 15 | Privacy | no Aadhaar OTP, UPI PIN, CVV or biometric collection; upload not exposed | UI warnings present; legal review pending |

## Release blockers

- Apply migrations to a non-production Supabase project and run the full RLS matrix.
- Build durable, server-enforced production implementations for admin/agent/support/notifications/commission; several current controls are illustrative only.
- Implement and verify a proper password recovery callback/update flow.
- Run browser/device accessibility and responsive testing; add automated component/E2E tests.
- Complete privacy/legal review, admin MFA, rate limits, alerting, backups, data retention and incident response.
- Connect Cloudflare Pages/GitHub only after the owner authorizes those external accounts. Configure and smoke-test the live URL.
