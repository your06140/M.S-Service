# API & integration notes

## Current data access

The frontend is a Vite SPA. `src/lib/supabase.ts` creates a Supabase client only when `VITE_SUPABASE_URL` and `VITE_SUPABASE_ANON_KEY` are provided. It uses Supabase Auth's persistent session/refresh handling. Browser requests use the public anon key and authenticated session; RLS is the authorization boundary.

| Operation | Supabase access | Auth/RLS expectation |
|---|---|---|
| Register | `auth.signUp({ email, password, options.data })` | email confirmation configured; auth trigger creates profile, customer record, customer role and demo wallet |
| Login/logout | `auth.signInWithPassword`, `auth.signOut` | Supabase Auth session |
| Forgot password | `auth.resetPasswordForEmail` | allow-list redirect URL configured; password recovery callback routes to a password-update screen and calls `auth.updateUser`; verify the redirect allow-list on deployment |
| Read active catalog | `services` + `service_categories` | authenticated, active rows only; admin can manage |
| Read request history | `service_requests.select(..., services(name))` | customer owns submitted request; assigned agent/network or admin as allowed |
| Submit service request | reads own `customers` row + service by slug, then inserts request | database requires own customer record, active service, and `available` or `manual_processing`; customer cannot assign agent or set status |

Requests produce server-generated `request_id` identifiers and DB timestamps. Frontend-only demo request IDs and records are clearly labelled and are not durable. Errors should be handled without returning secret provider details.

## Table model

See migrations for full columns and constraints. Core relations:

- `profiles.id` → `auth.users.id`; `user_roles.user_id` → profiles; role permissions represented by database `roles` + `user_roles`.
- `customers.profile_id` → profile; `service_requests.customer_id` → customers, `service_id` → services, `submitted_by` → profile and optional `assigned_agent_id` → agents.
- `service_documents.request_id` → request; private Storage object path starts with the owning Auth UUID.
- `agents.profile_id` → profile; `parent_agent_id`/`distributor_id` encode network mapping.
- `demo_wallets` and `transactions` are non-monetary demo tables (`is_demo = true` enforced); commission rules/entries likewise.
- `provider_configs` stores only a secret-name reference, not a credential. Store actual API keys in Edge Function secrets or Supabase Vault, never in SQL rows or frontend environment.

All sensitive tables enable RLS. `public.has_role()` derives roles from `auth.uid()` and the database role mapping. Do not authorize from React role state or user-editable metadata. Review policies with test accounts after every schema change.

## Error handling conventions

Supabase query errors are thrown by the small data helpers and surfaced in a generic toast. Production should map constraint codes to safe user messages, log sanitized server-side errors, and never include access tokens, document paths, provider secrets or raw PII in logs.

Potential request rejection reasons: no authenticated session, missing customer profile, inactive service, provider-required/coming-soon service, RLS denial or network failure. Do not retry non-idempotent requests blindly. If retry is added, use an idempotency key/table constraint.

## Future provider adapter contract (not currently connected)

Implement a provider only after an authorized provider agreement and security review. Suggested server-side interface:

```ts
export type ProviderRequest = {
  correlationId: string; serviceCode: string; payload: unknown;
};
export type ProviderResult =
  | { mode: 'mock'; accepted: false; message: 'No request sent to a provider' }
  | { mode: 'live'; accepted: true; providerReference: string; status: 'received' | 'processing' }
  | { mode: 'live'; accepted: false; errorCode: string; retryable: boolean };

export interface ServiceProvider {
  readonly providerKey: string;
  submit(input: ProviderRequest, signal: AbortSignal): Promise<ProviderResult>;
  verifyResponse(payload: unknown): ProviderResult;
}
```

Requirements for a future Edge Function: validate JWT and role server-side; schema-validate input/output; enforce request size, per-user rate limits, timeout and bounded retry for idempotent calls; load credentials from server-side secret storage; redact logs; record provider/status/error codes; never bypass OTP/CAPTCHA/authentication; do not claim success before verified provider response. For a development mock, return only an explicit `mode: 'mock'`, `accepted: false` response; do not mint fake real transaction references.

No provider endpoint, real credential, government connection or payment gateway is included in this project.

## Storage API boundary

The private bucket `customer-documents` permits PDF, JPEG and PNG up to 10 MiB, with object paths rooted at the authenticated owner UUID. A production upload flow still needs a consent step, MIME/signature validation, safe random object keys, signed URLs with short expiry, deletion/retention behavior and content scanning. Never make this bucket public. The present UI does not upload files.
