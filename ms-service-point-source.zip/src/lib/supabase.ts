import { createClient, type SupabaseClient } from '@supabase/supabase-js';
const url = import.meta.env.VITE_SUPABASE_URL as string | undefined;
const anonKey = import.meta.env.VITE_SUPABASE_ANON_KEY as string | undefined;
export const isSupabaseConfigured = Boolean(url && anonKey);
export const supabase: SupabaseClient | null = isSupabaseConfigured ? createClient(url!, anonKey!, {
  auth: { persistSession: true, autoRefreshToken: true, detectSessionInUrl: true },
}) : null;

export type DbService = { id:string; name:string; slug:string; description:string; availability:string; official_url?:string|null };
export type DbRequest = { request_id:string; status:string; submitted_at:string; customer_notes:string; services?:{name:string}|null };
export async function fetchActiveServices(): Promise<DbService[]> {
  if (!supabase) return [];
  const {data,error}=await supabase.from('services').select('id,name,slug,description,availability,official_url').eq('active',true).order('name');
  if(error) throw error; return data ?? [];
}
export async function fetchMyRequests(): Promise<DbRequest[]> {
  if (!supabase) return [];
  const {data,error}=await supabase.from('service_requests').select('request_id,status,submitted_at,customer_notes,services(name)').order('submitted_at',{ascending:false});
  if(error) throw error; return (data ?? []) as unknown as DbRequest[];
}
export async function createMyRequest(serviceSlug:string,notes:string):Promise<string> {
  if(!supabase) throw new Error('Supabase is not configured.');
  const {data:{user},error:userError}=await supabase.auth.getUser();
  if(userError||!user) throw new Error('Please sign in again to submit a request.');
  const [{data:customer,error:customerError},{data:service,error:serviceError}]=await Promise.all([
    supabase.from('customers').select('id').eq('profile_id',user.id).single(),
    supabase.from('services').select('id,availability,active').eq('slug',serviceSlug).single()
  ]);
  if(customerError||!customer) throw new Error('Customer profile is not ready. Contact support.');
  if(serviceError||!service||!service.active) throw new Error('This service is not currently available.');
  if(service.availability==='coming_soon'||service.availability==='api_integration_required') throw new Error('This service cannot accept requests yet.');
  const {data,error}=await supabase.from('service_requests').insert({customer_id:customer.id,service_id:service.id,submitted_by:user.id,customer_notes:notes,status:'submitted'}).select('request_id').single();
  if(error) throw error; return data.request_id;
}
