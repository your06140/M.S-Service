begin;
-- Prevent self-service edits to fields that control identity, status or entitlements.
create or replace function public.guard_profile_self_update() returns trigger language plpgsql security definer set search_path=public,auth as $$
begin
 if auth.uid()=old.id and not public.is_admin() then
  if new.id is distinct from old.id or new.email is distinct from old.email or new.account_status is distinct from old.account_status or new.customer_code is distinct from old.customer_code then
   raise exception 'Protected profile fields cannot be changed by the account owner';
  end if;
 end if;
 return new;
end $$;
create trigger profiles_guard_self_update before update on public.profiles for each row execute function public.guard_profile_self_update();

create or replace function public.guard_customer_identity() returns trigger language plpgsql security definer set search_path=public,auth as $$
begin
 if auth.uid()=old.profile_id and not public.is_admin() and (new.id is distinct from old.id or new.profile_id is distinct from old.profile_id or new.customer_id is distinct from old.customer_id) then
  raise exception 'Customer identifiers cannot be changed';
 end if;
 return new;
end $$;
create trigger customers_guard_identity before update on public.customers for each row execute function public.guard_customer_identity();

-- Public agent onboarding only creates pending retailer records. Higher tiers and mappings are admin-controlled.
drop policy if exists agents_self_register on public.agents;
create policy agents_self_register on public.agents for insert to authenticated with check(profile_id=auth.uid() and status='pending' and agent_level='retailer' and parent_agent_id is null and distributor_id is null);

-- Customer inserts are constrained to active service offerings that can actually accept an assistance request.
drop policy if exists request_insert_customer on public.service_requests;
create policy request_insert_customer on public.service_requests for insert to authenticated with check(
 submitted_by=auth.uid() and status='submitted' and assigned_agent_id is null and
 exists(select 1 from public.customers c where c.id=customer_id and c.profile_id=auth.uid()) and
 exists(select 1 from public.services s where s.id=service_id and s.active and s.availability in ('available','manual_processing')) and
 char_length(customer_notes)<=2000
);

-- Only administrators can add ledger rows; clients can never mutate money-like balances.
create policy wallets_admin_update on public.demo_wallets for update to authenticated using(public.is_admin()) with check(public.is_admin());
create policy wallets_admin_insert on public.demo_wallets for insert to authenticated with check(public.is_admin());
create policy transactions_admin_insert on public.transactions for insert to authenticated with check(public.is_admin() and is_demo);
create policy commission_admin_insert on public.commission_entries for insert to authenticated with check(public.is_admin() and is_demo);

-- Minimal audit metadata: record id and operation only; never log PII or document contents.
create or replace function public.audit_sensitive_change() returns trigger language plpgsql security definer set search_path=public,auth as $$
declare rid text; begin
 if tg_op='DELETE' then rid:=coalesce(to_jsonb(old)->>'id',to_jsonb(old)->>'user_id'); else rid:=coalesce(to_jsonb(new)->>'id',to_jsonb(new)->>'user_id'); end if;
 insert into public.audit_logs(actor_id,action,table_name,record_id,metadata)
 values(auth.uid(),lower(tg_op),tg_table_name,rid,jsonb_build_object('source','database_trigger'));
 if tg_op='DELETE' then return old; else return new; end if;
end $$;
revoke all on function public.audit_sensitive_change() from public,anon,authenticated;
do $$ declare t text; begin foreach t in array array['user_roles','agents','distributors','services','service_requests','transactions','commission_rules','commission_entries','support_tickets','provider_configs'] loop
 execute format('create trigger %I_audit after insert or update or delete on public.%I for each row execute function public.audit_sensitive_change()',t,t);
end loop; end $$;
commit;
