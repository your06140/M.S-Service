begin;
insert into public.service_categories(name,slug,sort_order) values
('PAN Services','pan-services',1),('Government Services','government-services',2),('Financial Services','financial-services',3),('Recharge & Bills','recharge-bills',4),('Document Services','document-services',5)
on conflict(slug) do update set name=excluded.name,sort_order=excluded.sort_order;
with catalog(name,slug,category_slug,availability,description) as (values
('New PAN Application Assistance','new-pan-application-assistance','pan-services','manual_processing','Guided application support and document checklist.'),
('PAN Correction Assistance','pan-correction-assistance','pan-services','manual_processing','Help with correction requests and application follow-up.'),
('PAN Reprint Assistance','pan-reprint-assistance','pan-services','manual_processing','Assistance with reprint requests through official channels.'),
('PAN Status','pan-status','pan-services','coming_soon','Status guidance for submitted applications.'),
('UTIITSL Services','utiitsl-services','pan-services','api_integration_required','Provider integration is not configured.'),
('Protean Services','protean-services','pan-services','api_integration_required','Provider integration is not configured.'),
('Voter ID Assistance','voter-id-assistance','government-services','manual_processing','Application guidance and document preparation.'),
('Driving Licence Assistance','driving-licence-assistance','government-services','manual_processing','Support navigating the official application process.'),
('RC Services','rc-services','government-services','coming_soon','Vehicle registration guidance.'),
('Ration Card Assistance','ration-card-assistance','government-services','manual_processing','Application and correction assistance.'),
('Income Certificate Assistance','income-certificate-assistance','government-services','manual_processing','Document preparation support.'),
('Caste Certificate Assistance','caste-certificate-assistance','government-services','manual_processing','Document preparation support.'),
('Domicile Certificate Assistance','domicile-certificate-assistance','government-services','manual_processing','Local certificate application guidance.'),
('ABHA Card Assistance','abha-card-assistance','government-services','coming_soon','Health ID application guidance.'),
('Ayushman Bharat Assistance','ayushman-bharat-assistance','government-services','manual_processing','Eligibility and official portal guidance.'),
('Mobile Recharge','mobile-recharge','recharge-bills','api_integration_required','Recharge fulfillment requires an authorized provider.'),
('DTH Recharge','dth-recharge','recharge-bills','api_integration_required','Recharge fulfillment requires an authorized provider.'),
('Electricity Bill Assistance','electricity-bill-assistance','recharge-bills','manual_processing','Bill payment guidance; no payment collected here.'),
('BBPS','bbps','recharge-bills','api_integration_required','Requires an authorized BBPS partner integration.'),
('Insurance Assistance','insurance-assistance','financial-services','manual_processing','General assistance; products subject to licensed partners.'),
('AEPS','aeps','financial-services','api_integration_required','Requires authorized banking correspondent integration.'),
('Money Transfer','money-transfer','financial-services','api_integration_required','Requires authorized provider; no transfers enabled.'),
('Banking Correspondent Services','banking-correspondent-services','financial-services','coming_soon','Partner onboarding and authorization required.'),
('PDF Merge','pdf-merge','document-services','coming_soon','Local PDF utility planned; no files are processed in this preview.'),
('PDF Split','pdf-split','document-services','coming_soon','Local document utility planned.'),
('PDF Compress','pdf-compress','document-services','coming_soon','Local document utility planned.'),
('Image Resize','image-resize','document-services','coming_soon','Image preparation utility planned.'),
('Passport Photo','passport-photo','document-services','manual_processing','Photo preparation and print assistance.'),
('JPG to PDF','jpg-to-pdf','document-services','coming_soon','Local document utility planned.'),
('PDF to Image','pdf-to-image','document-services','coming_soon','Local document utility planned.'),
('Print & Scan','print-scan','document-services','manual_processing','Visit our local service desk for print and scan support.')
)
insert into public.services(category_id,name,slug,availability,description)
select c.id,x.name,x.slug,x.availability,x.description from catalog x join public.service_categories c on c.slug=x.category_slug
on conflict(slug) do update set category_id=excluded.category_id,name=excluded.name,availability=excluded.availability,description=excluded.description,updated_at=now();
commit;
