#!/usr/bin/env node
/**
 * One-time controlled first-admin bootstrap. Run locally with a Supabase service role secret.
 * Does not create/set a password. For a new email it sends Supabase's secure invitation.
 */
import { createClient } from '@supabase/supabase-js';
const { SUPABASE_URL, SUPABASE_SERVICE_ROLE_KEY, ADMIN_EMAIL, CONFIRM_EXISTING_USER_EMAIL } = process.env;
if (!SUPABASE_URL || !SUPABASE_SERVICE_ROLE_KEY || !ADMIN_EMAIL) {
  console.error('Set SUPABASE_URL, SUPABASE_SERVICE_ROLE_KEY and ADMIN_EMAIL in your local environment. Do not pass secrets as committed files.');
  process.exit(1);
}
const email=ADMIN_EMAIL.trim().toLowerCase();
if (email !== ADMIN_EMAIL.trim()) throw new Error('Use a normalized email address.');
const supabase=createClient(SUPABASE_URL,SUPABASE_SERVICE_ROLE_KEY,{auth:{persistSession:false,autoRefreshToken:false}});
const {data:listed,error:listError}=await supabase.auth.admin.listUsers({page:1,perPage:1000});
if(listError) throw listError;
let user=listed.users.find(u=>u.email?.toLowerCase()===email);
if(user){
  if(CONFIRM_EXISTING_USER_EMAIL?.toLowerCase()!==email){
    console.error('Existing auth account found. To prevent accidental privilege escalation, set CONFIRM_EXISTING_USER_EMAIL to the exact ADMIN_EMAIL and rerun after verifying ownership.');
    process.exit(2);
  }
}else{
  const {data,error}=await supabase.auth.admin.inviteUserByEmail(email,{redirectTo:process.env.ADMIN_REDIRECT_URL});
  if(error) throw error; user=data.user;
}
if(!user) throw new Error('Unable to resolve invited Auth user.');
const {data:role,error:roleError}=await supabase.from('roles').select('id').eq('code','admin').single();
if(roleError) throw roleError;
const {error:grantError}=await supabase.from('user_roles').upsert({user_id:user.id,role_id:role.id},{onConflict:'user_id,role_id'});
if(grantError) throw grantError;
const {error:logError}=await supabase.from('audit_logs').insert({actor_id:user.id,action:'admin.bootstrap',table_name:'user_roles',record_id:user.id,metadata:{email,method:user.created_at===user.updated_at?'invite_or_initial_setup':'controlled_existing_account_grant'}});
if(logError) console.warn('Admin grant succeeded; audit insert returned:',logError.message);
console.log(`Admin role granted to ${email}. Use the secure Supabase email invitation/password recovery flow; no password was generated or stored by this script.`);
