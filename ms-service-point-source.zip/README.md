# M.S SERVICE POINT

**Your Trusted Digital Service & Print Center** · English / Hindi · INR · Asia/Kolkata

A mobile-first React + TypeScript portal UI and Supabase starter for a local digital-services and agent-management operation. Original brand and implementation; no copied private code, credentials or assets.

> **Important status:** This is a functional development preview, not a deployed production service. It has not been connected to a Supabase project, GitHub repository, Cloudflare account or any government/provider API. No live website URL or real test login exists yet. The demo UI clearly labels sample balances/data; service statuses do not imply an API or government connection. Do not collect or upload real customer documents to this preview.

## Architecture (Phase 1)

- **Web:** React 18 + TypeScript + Vite, responsive custom CSS (Tailwind is configured), Lucide icons. Cloudflare Pages static build target.
- **Auth/data:** Supabase Auth + PostgreSQL. Browser uses only the public anon key; database access is intended to be guarded by RLS. Supabase client functions implement sign-up/sign-in/password reset, session persistence, fetching own requests and submitting eligible requests.
- **Authorization:** role grants are stored in `user_roles`, never trusted from UI state. Admin bootstrap is a local, controlled script using a service-role secret, with no hardcoded password. Database policies and a hardening migration constrain identity/status edits, service-request eligibility and demo-ledger writes.
- **Files:** private `customer-documents` bucket with PDF/JPEG/PNG and 10 MiB caps; metadata and object policies are in SQL. UI uploads are intentionally not enabled until deployment and access tests are complete.
- **Provider layer:** service catalog advertises manual processing, API-required and coming-soon states honestly. No provider credentials or live external API integration are present.
- **Ledger:** all wallet and commission figures in the workspace are explicitly non-monetary preview data; no deposits, payments, withdrawals or payouts exist.

## Phase 2 — Frontend

Implemented: responsive workspace dashboard; searchable/filterable catalog; status-labelled service cards; request modal/tracker; sample demo ledger; agent network; gated admin-preview navigation; profile/preferences; support form; authentication screens; pricing, FAQ, About, privacy, terms and refund content; responsive mobile nav and reduced-motion support.

The UI's role selector is **demo-only** and exists for visual review. It must not be presented as role switching in production. Authentication screens are real Supabase flows only after environment configuration. Several secondary dashboard actions are illustrative UI and need their production workflows connected before launch.

## Phase 3–7 — Database, flows, security, testing

SQL migrations:
1. `supabase/migrations/0001_initial.sql` — tables, indexes, auth trigger, baseline RLS, private storage bucket.
2. `supabase/migrations/0002_service_catalog.sql` — catalog seed with conservative availability statuses.
3. `supabase/migrations/0003_security_hardening.sql` — protected profile fields, retailer-only public agent registration, request eligibility check, admin-only demo-ledger writes, audit triggers.

**Tests run here:** `npm run build` (TypeScript + Vite production build: passed); `npm audit --omit=dev` (0 production dependency vulnerabilities at build time). The full dependency audit still reports high-severity findings in development-tool transitive `picomatch`/Tailwind/Vite dependencies with no compatible fixed version available in this environment; review `npm audit` before deployment and upgrade when upstream fixes land. This is not a claim that the application is security-certified.

**Not yet verified:** SQL against a real Supabase project, RLS policy behavior in a live project, real email confirmation/password recovery, mobile device browser tests, document uploads/download, full role workflows, support-ticket persistence, audit log review, provider integration, Cloudflare deployment, production smoke tests. Do not launch until these pass.

## Run locally (free)

Requirements: Node.js 20.19+ and npm. No paid service is required for local development.

```bash
cd ms-service-point
npm install
cp .env.example .env.local
# Leave Supabase values blank for the clearly-labelled local demo.
npm run dev
```

Open the local URL printed by Vite. The preview uses sample records in memory when no Supabase keys are set; refreshing clears newly submitted demo requests. Do not put real customer data into demo mode.

Build/check:

```bash
npm run typecheck
npm run build
npm audit --omit=dev
```

## Configure Supabase (free tier)

1. Create a Supabase project using its free plan; do not add billing/payment details. Free tier limits and availability can change. Use a unique project password and protect it in a password manager.
2. In Supabase SQL Editor, apply migrations in numeric order (`0001`, `0002`, `0003`). Inspect policies in the dashboard. Never disable RLS on user or document tables.
3. In Auth settings, set the Site URL and allowed redirect URLs for local development and the final `https://<your-project>.pages.dev` origin. Keep email confirmation enabled. Configure rate limits and SMTP carefully; Supabase's built-in email has delivery limits. A custom SMTP provider is optional and may have costs—do not activate paid trials.
4. Copy the **Project URL** and **anon/public key** into `.env.local` as `VITE_SUPABASE_URL` and `VITE_SUPABASE_ANON_KEY`. The anon key is intended for browser use; RLS is mandatory. Never expose the service-role key in `VITE_*`, source code, browser bundles, GitHub or Cloudflare Pages variables.
5. Create the first administrator securely as described in [docs/ADMIN-INITIALIZATION.md](docs/ADMIN-INITIALIZATION.md). No public admin registration exists. Confirm the new email, set a unique strong password through the Supabase invite/recovery flow and verify audit records.
6. Test sign-up, sign-in, sign-out, reset email, request insertion, request isolation between two users, unauthorized admin queries, and table/storage policies with separate test users before adding real records.

## Admin bootstrap

A one-time script invites/grants a specific administrator. It never creates or stores a password. It must be run on a trusted local machine, never in the browser or Cloudflare build. Follow [docs/ADMIN-INITIALIZATION.md](docs/ADMIN-INITIALIZATION.md); the service-role secret stays in the shell environment and is rotated if exposed.

## Free Cloudflare Pages deployment

1. Create a GitHub repository from this folder and push source. Ensure `.env.local`, `.env`, service-role keys and Supabase credentials are not committed. `.gitignore` excludes local env files.
2. Create a Cloudflare Pages project connected to that repository using the free Pages plan. Choose **Vite**; build command `npm run build`; output directory `dist`; Node version 20.19 or later.
3. Add only `VITE_SUPABASE_URL` and `VITE_SUPABASE_ANON_KEY` as Pages environment variables (production and preview only as appropriate). These are public browser config; all privileged secrets stay server-side.
4. Deploy to the free `*.pages.dev` subdomain, add that exact origin to Supabase Auth redirect allow-list and set the Auth Site URL.
5. Verify the live URL using a new customer test account and a separate admin account. Check mobile viewport, sign-in/out, password reset, own-request isolation, rejected non-owner queries, admin role gates, and that direct `storage.objects` public access fails. Remove temporary test data afterward.

No deployment was performed because external Supabase, GitHub and Cloudflare accounts require owner authorization and project-specific configuration. No domain or paid trial has been purchased or activated.

## Test users and sample data

No credentials are hardcoded or shipped. Create safe test users yourself via Supabase Auth sign-up with throwaway test email aliases. Use the bootstrap script for one admin. Create retailer/distributor test requests only after admin approval through controlled SQL/admin tooling. `0002_service_catalog.sql` seeds the 31 service definitions; all provider- or government-dependent services are marked non-operational. The UI's sample requests/ledger figures are fictitious, in-memory preview records—not test account credentials, real transactions or completed government applications.

## Known gaps before production

- Complete dashboard CRUD and server-side workflows for agent approvals/mapping, KYC review, request assignment, notifications, support, exports and content management.
- Add verified file-upload UI with client + server validation, private-bucket signed URL flow, malware scanning/retention policy, audit and consent; do not accept Aadhaar OTP, UPI PIN, CVV or biometric data.
- Add server-side rate limiting, abuse protection, admin MFA, stronger security headers/CSP, monitoring, backups/retention, incident process and legal/privacy review. Configure Supabase Auth limits in dashboard.
- Verify the password recovery redirect/update flow in the deployed Supabase Auth configuration. Add a production provider adapter/Edge Function only after authorized contracts, credential storage and response validation. Current catalog intentionally does not call providers.
- Translate complete UI copy into Hindi and add accessibility/device/automated RLS tests.
- Consider fees/limits for optional payment gateway, custom domain, custom email, SMS or authorized provider APIs; keep them off unless explicitly approved. Free alternative: Pages `pages.dev`, Supabase free tier, email-only Auth and manual official-portal assistance.

## Project files

- `src/App.tsx` — screens and demo interactions
- `src/styles.css` — mobile-first luxury black/gold design system
- `src/lib/supabase.ts` — public client and customer request/auth data functions
- `supabase/migrations/` — PostgreSQL schema, catalog, policies and security hardening
- `scripts/grant-admin.mjs` — controlled admin bootstrap (local only)
- `docs/API.md` — data/API contract and provider safety boundaries
- `docs/ADMIN-INITIALIZATION.md` — first-admin process
- `docs/TEST-PLAN.md` — deployment test checklist
